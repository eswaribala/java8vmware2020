package com.vmware.ecomm.facades;

import java.util.Random;
//@FunctionalInterface
public interface Payment {
	
	public static int getOTP()
	{
		return new Random().nextInt(10000);
	}

	public static int getOTP(int seed)
	{
		return new Random().nextInt(seed);
	}
	
	public static boolean validateCreditCard(String cardNumber,int limit)
	{
		boolean status=false;
		if(cardNumber.length()==limit)
			status=true;
		return status;
		
	}
	
	
	
}
