package com.vmware.ecomm.facades;

import java.util.ArrayList;
import java.util.List;

import com.vmware.ecomm.models.Product;

public interface ProductFacade {
	
	default Product addProduct(Product product)
	{
		return new Product();
	}
	default List<Product> getAllProducts()
	{
		return new ArrayList<Product>();
	}
	default Product getProductById(long productId)
	{
		return new Product();
	}
	
	Product updateProduct(Product product);
	boolean deleteProduct(long productId);

	public static void shippingCost(int charge)
	{
		System.out.println("Shipping cost"+charge);
	}
	
	
}
