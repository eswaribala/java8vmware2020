package com.vmware.ecomm.facades;

import com.vmware.ecomm.models.Product;

@FunctionalInterface
public interface ProductAvailableFacade {

	String isProductAvailable(int productId);
	//Product updateProduct(Product product);
	//boolean deleteProduct(long productId);
}
