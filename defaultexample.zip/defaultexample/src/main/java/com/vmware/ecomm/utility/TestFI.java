package com.vmware.ecomm.utility;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Random;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import com.vmware.ecomm.facades.Payment;
import com.vmware.ecomm.facades.TriFunction;
import com.vmware.ecomm.models.Product;

public class TestFI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Product> products = new ProductService().getAllProducts();
		
		//define function		
		Function<Long,String> testProduct=(Id)->{
			String message="Not Found";
			for(Product product : products)
			{
				if(product.getProductId()==Id)
				{
					message="Found";
					break;
				}
			}
			return message;
		};
		
		//invoke the function
		System.out.println(testProduct.apply((long) (new Random().nextInt(10000))));
		

		//BiFunction
		
		//define function		
				BiFunction<Long,Long,String> testBudget=(cost,budget)->{
					String message="Not Within Budget";
					if(cost<=budget)
						message="afforadable";
					return message;
				};
				
				//invoke the function
				System.out.println(testBudget.apply((long) (new Random().nextInt(10000)),
						(long) (new Random().nextInt(10000))));
		
				
				TriFunction<Product,Long,LocalDate,String> testBudgetExpiry=(product,budget,givenDate)->{
					String message="Not Within Budget,Expired";
					if(product.getCost()<=budget)
					{
						message="affordable";
						if(product.getDop().isAfter(givenDate))
						{
							message+=",Still Alive";
						}
					}
					return message;
				};
				
				//invoke the function
				System.out.println(testBudgetExpiry.apply(new Product(1,"Pickle",LocalDate.of(2020, 4, 27),200),
						(long) (new Random().nextInt(1000)),LocalDate.of(2020,6,6)));		
		
	
	//consumer 
	//define			
	Consumer<List<Product>> testConsumer=(productList)->{
		
		for(Product product:productList)
		{
			if(product.getDop().getMonth().equals(Month.APRIL))
				System.out.println(product.getName()+","+product.getCost());
		}
		
	};
	
	//invoke
	testConsumer.accept(products);
	
	//Biconsumer
	//define			
		BiConsumer<LocalDate,Long> testBiConsumer=(dop,cost)->{
			
			for(Product product:products)
			{
				if(product.getDop().isBefore(dop) && (product.getCost()<=cost))
					System.out.println("Bi Consumer"+","+product.getName()+","+product.getCost());
			}
			
		};
		
		//invoke
		testBiConsumer.accept(LocalDate.of(2020, 5, 3),2000L);
	
	
	 //Supplier
		//Supplier does not take input parameter
		Supplier<Integer> otpSupplier=Payment::getOTP;		
		System.out.println("OTP Gen...."+","+otpSupplier.get());
	//Function
		Function<Integer,Integer> otpFunction=Payment::getOTP;
		System.out.println("OTP Gen Function...."+","+otpFunction.apply(100));
		
	//Predicate
		
	BiPredicate<String,Integer> testCard=Payment::validateCreditCard;
	System.out.println("Card Status..."+"-->"+testCard.test("0123456789012345", 16) );
	
	
	
	}

}
