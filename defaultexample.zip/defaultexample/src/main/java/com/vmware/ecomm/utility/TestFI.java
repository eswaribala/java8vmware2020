package com.vmware.ecomm.utility;

import java.util.Random;
import java.util.function.Function;

import com.vmware.ecomm.models.Product;

public class TestFI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//define function		
		Function<Long,String> testProduct=(Id)->{
			String message="Not Found";
			for(Product product : new ProductService().getAllProducts())
			{
				if(product.getProductId()==Id)
				{
					message="Found";
					break;
				}
			}
			return message;
		};
		
		//invoke the function
		System.out.println(testProduct.apply((long) (new Random().nextInt(10000))));
		

	}

}
