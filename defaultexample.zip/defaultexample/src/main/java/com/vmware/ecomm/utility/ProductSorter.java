package com.vmware.ecomm.utility;

import java.util.Comparator;

import com.vmware.ecomm.models.Product;

public class ProductSorter implements Comparator<Product>{

	@Override
	public int compare(Product o1, Product o2) {
		// TODO Auto-generated method stub
		return (int) (o1.getProductId()-o2.getProductId());
		
	}

}
