package com.vmware.ecomm.models;

import java.time.LocalDate;

import lombok.Data;

@Data
public class Product {
	
	private long productId;
	private String name;
	private LocalDate dop;
	private long cost;

}
