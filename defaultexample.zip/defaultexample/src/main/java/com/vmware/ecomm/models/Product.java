package com.vmware.ecomm.models;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
	
	private long productId;
	private String name;
	private LocalDate dop;
	private long cost;

}
