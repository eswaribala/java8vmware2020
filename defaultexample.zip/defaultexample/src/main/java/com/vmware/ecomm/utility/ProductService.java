package com.vmware.ecomm.utility;

import com.vmware.ecomm.facades.ProductFacade;
import com.vmware.ecomm.models.Product;

public class ProductService implements ProductFacade{

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteProduct(long productId) {
		// TODO Auto-generated method stub
		return false;
	}

}
