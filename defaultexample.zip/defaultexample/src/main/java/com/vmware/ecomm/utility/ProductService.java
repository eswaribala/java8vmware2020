package com.vmware.ecomm.utility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.vmware.ecomm.facades.ProductFacade;
import com.vmware.ecomm.models.Product;

public class ProductService implements ProductFacade{

	
	
	
	
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return createProducts();
	}

	@Override
	public Product updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteProduct(long productId) {
		// TODO Auto-generated method stub
		return false;
	}

	
	private List<Product> createProducts()
	{
		List<Product> productList=new ArrayList<Product>();
		Product product=null;
		
		for(int i=0;i<10;i++)
		{
			product = new Product(new Random().nextInt(10000),"product"+i,LocalDate.of(2020, 
					new Random().nextInt(10)+1, new Random().nextInt(27)+1), 
					new Random().nextInt(10000));
			productList.add(product);
		}
		
		return productList;
	}
	
}
