package com.vmware.ecomm.utility;

import java.util.Random;

import com.vmware.ecomm.facades.ProductAvailableFacade;

public class TestProductAvailable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     //definition for Lambda Expression
		ProductAvailableFacade productAvailableFacade =(productId)->{
		
			if(productId>500)
				return "Product Available";
			else
				return "Product Not Available";						
		};
	
	//invoke the lambda expression
		System.out.println(productAvailableFacade.isProductAvailable
				(new Random().nextInt(1000)));
		
		
	}

}
