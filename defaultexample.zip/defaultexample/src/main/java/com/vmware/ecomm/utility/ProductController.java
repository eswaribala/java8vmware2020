package com.vmware.ecomm.utility;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import com.vmware.ecomm.facades.ProductFacade;
import com.vmware.ecomm.models.Product;

public class ProductController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProductService productService=new ProductService();
		ProductFacade.shippingCost(5000);
		System.out.println("Before Sorting.....");
		for(Product product: productService.getAllProducts())
		{
			System.out.println(product.getProductId()+","
		           +product.getName()+","+product.getDop().toString()
		           +","+product.getCost());
		}
		
		System.out.println("After Sorting....");
		
		Comparator<Product> idComparator = (Product p1, Product p2) -> (int) (p1.getProductId()
				-p2.getProductId());

		Collections.sort(productService.getAllProducts(), idComparator);
		
		
		
	}

}
