package com.vmware.ecomm.utility;

import com.vmware.ecomm.facades.ProductFacade;

public class ProductController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ProductService productService=new ProductService();
		ProductFacade.shippingCost(5000);
		
	}

}
