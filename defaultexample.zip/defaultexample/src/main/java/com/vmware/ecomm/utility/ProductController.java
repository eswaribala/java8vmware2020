package com.vmware.ecomm.utility;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Logger;

import com.vmware.ecomm.facades.ProductFacade;
import com.vmware.ecomm.models.Product;

import lombok.extern.slf4j.Slf4j;

public class ProductController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ProductService productService=new ProductService();
		ProductFacade.shippingCost(5000);
		System.out.println("Before Sorting.....");
		for(Product product: productService.getAllProducts())
		{
			System.out.println(product.getProductId()+","
		           +product.getName()+","+product.getDop().toString()
		           +","+product.getCost());
		}
		
		System.out.println("After Sorting....");
		
		//Comparator<Product> idComparator = (Product p1, Product p2) -> (int) (p1.getCost()
			//	-p2.getCost());
		
		List<Product> products=productService.getAllProducts();

		//Collections.sort(products, idComparator);
		products.sort((Product p1, Product p2) -> (int) (p1.getCost()
				-p2.getCost()));
		for(Product product: products)
		{
			System.out.println(product.getProductId()+","
		           +product.getName()+","+product.getDop().toString()
		           +","+product.getCost());
		}
		
		
	}

}
