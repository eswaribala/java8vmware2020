package com.continental.utility;

import com.continental.models.Cab;
import com.continental.models.Flight;
import com.continental.models.Hotel;
import com.continental.models.TicketBooking;
import com.continental.models.TicketBookingConst;
import com.continental.models.Train;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Flight flight =new Flight();
		flight.setFlightCode("6E586");
		flight.setServiceProvider("Indigo");
		Cab cab = new Cab();
		cab.setCabProvider("Meru");
		cab.setCabType("Sedan");
		
		//TicketBooking<Flight,Cab> tbooking=new TicketBooking<>(flight,cab);
		TicketBookingConst tbooking=new TicketBookingConst(flight,cab);
		TicketBookingConst.printBoardingPass(tbooking);
		
		Train train=new Train();
		train.setTrainNo(8877);
		train.setFromCity("Chennai");
		train.setToCity("Delhi");
		Hotel hotel = new Hotel();		
		hotel.setHotelName("Lemon Tree");
		hotel.setAddress("Bangalore");
		TicketBooking<Train,Hotel> train_booking=new TicketBooking<>(train,hotel);
		for(Object obj : train_booking.getInstance())
		{
			if (obj instanceof Train)
				System.out.println(((Train) obj).getTrainNo());
			if(obj instanceof Hotel)
				System.out.println(((Hotel) obj).getHotelName());
		}
		
		
		
		
		
		
	}

}
