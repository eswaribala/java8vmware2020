package com.continental.facades;

public abstract class TravelMode {

}
