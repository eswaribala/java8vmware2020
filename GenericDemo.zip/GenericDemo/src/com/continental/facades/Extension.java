package com.continental.facades;

public interface Extension {

}
