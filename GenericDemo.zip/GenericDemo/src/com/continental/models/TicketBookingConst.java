package com.continental.models;

import java.util.ArrayList;
import java.util.List;

import com.continental.facades.Extension;
import com.continental.facades.TravelMode;

public class TicketBookingConst {

	private TravelMode instance1;
	private Extension instance2;
    private List<Object> instanceList; 
	public <T1,T2> TicketBookingConst(T1 instance1,T2 instance2) {
		super();
		this.instance1 = (TravelMode) instance1;
		this.instance2=(Extension) instance2;
		instanceList=new ArrayList<Object>();
		instanceList.add(this.instance1);
		instanceList.add(this.instance2);
	}
	
	public List<Object> getInstance()
	{
		return instanceList;
	}
	
	
	public static <T1> void printBoardingPass(T1 info1)
	{
		TicketBookingConst tbooking=(TicketBookingConst) info1;
		
		for(Object obj : tbooking.getInstance())
		{
			if (obj instanceof Flight)
				System.out.println(((Flight) obj).getServiceProvider());
			if(obj instanceof Cab)
				System.out.println(((Cab) obj).getCabProvider());
		}
		
		
	}
	
}
