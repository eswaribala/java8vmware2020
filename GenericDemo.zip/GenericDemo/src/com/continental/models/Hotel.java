package com.continental.models;

import com.continental.facades.Extension;

public class Hotel implements Extension{

	private String hotelName;
	private String address;
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
