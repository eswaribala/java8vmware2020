package com.continental.models;

import com.continental.facades.Extension;

public class Cab implements Extension{

	private String cabProvider;
	private String cabType;
	public String getCabProvider() {
		return cabProvider;
	}
	public void setCabProvider(String cabProvider) {
		this.cabProvider = cabProvider;
	}
	public String getCabType() {
		return cabType;
	}
	public void setCabType(String cabType) {
		this.cabType = cabType;
	}
	
	
}
