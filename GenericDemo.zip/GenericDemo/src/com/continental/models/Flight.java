package com.continental.models;

import com.continental.facades.TravelMode;

public class Flight extends TravelMode{

	private String flightCode;
	private String serviceProvider;
	public String getFlightCode() {
		return flightCode;
	}
	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}
	public String getServiceProvider() {
		return serviceProvider;
	}
	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}
	
	
}
