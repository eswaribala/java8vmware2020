package com.continental.models;

import java.util.ArrayList;
import java.util.List;

public class TicketBooking <T1,T2>{
	
	private T1 instance1;
	private T2 instance2;
    private List<Object> instanceList; 
	public TicketBooking(T1 instance1,T2 instance2) {
		super();
		this.instance1 = instance1;
		this.instance2=instance2;
		instanceList=new ArrayList<Object>();
		instanceList.add(this.instance1);
		instanceList.add(this.instance2);
	}
	
	public List<Object> getInstance()
	{
		return instanceList;
	}
	

}
