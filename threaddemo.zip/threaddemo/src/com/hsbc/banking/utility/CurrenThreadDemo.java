package com.hsbc.banking.utility;

import com.hsbc.banking.models.AnimationRunnableDemo;
import com.hsbc.banking.models.AnimationThread;

public class CurrenThreadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Thread.currentThread().getName());
		
		//foreground thread
		AnimationThread thread=new AnimationThread("Animation-Thread","HSBC");
		thread.start();
		//runnable thread
		AnimationRunnableDemo animationRunnableDemo=new AnimationRunnableDemo
				("Animation Runnable Thread","HSBC");
		Thread threadInstance=new Thread(animationRunnableDemo);
		threadInstance.start();
		
		
		
	}

}
