package com.hsbc.banking.utility;

import com.hsbc.banking.models.Account;
import com.hsbc.banking.models.AccountThread;

public class NonSynchronizationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Account account=new Account(1000);
		AccountThread thread1=new AccountThread(account,"A",750);
		AccountThread thread2=new AccountThread(account,"B",500);
		
	}

}
