package com.hsbc.banking.utility;

import com.hsbc.banking.models.Tweet;

public class InterThreadApp {

	public static void main(String...args)
	{
		//synchronization with single resource
		Tweet tweet = new Tweet();	
		Thread t1=new Thread(tweet,"Producer");
		Thread t2=new Thread(tweet,"Consumer-1");
		Thread t3=new Thread(tweet,"Consumer-2");
		Thread t4=new Thread(tweet,"Consumer-3");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
		
	}
}
