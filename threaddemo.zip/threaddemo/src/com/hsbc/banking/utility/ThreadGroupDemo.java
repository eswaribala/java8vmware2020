package com.hsbc.banking.utility;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.hsbc.banking.models.WorkerThread;

public class ThreadGroupDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ThreadGroup threadGroup=new ThreadGroup("Group-1");
		Thread thread1 = new Thread(threadGroup,new WorkerThread("Thread-1"));
		Thread thread2 = new Thread(threadGroup,new WorkerThread("Thread-2"));
		Thread thread3 = new Thread(threadGroup,new WorkerThread("Thread-3"));
		Thread thread4 = new Thread(threadGroup,new WorkerThread("Thread-4"));
		int agc = threadGroup.activeGroupCount ();
		System.out.println ("Active thread groups in " + threadGroup.getName () +" thread group: " + agc);
		threadGroup.list (); 
		threadGroup=new ThreadGroup("Group-2");
		Thread thread5=new Thread(threadGroup,new WorkerThread("Thread-5"));
		agc = threadGroup.activeGroupCount ();
		System.out.println ("Active thread groups in " + threadGroup.getName () +" thread group: " + agc);
		threadGroup.list ();  
		//Thread Pool
		ExecutorService services=Executors.newFixedThreadPool(3);
		services.execute(thread1);
		services.execute(thread2);
		services.execute(thread3);
		services.execute(thread4);
		services.execute(thread5);
		services.shutdown();
		
        
	}

}
