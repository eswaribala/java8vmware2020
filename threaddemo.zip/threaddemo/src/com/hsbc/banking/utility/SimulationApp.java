package com.hsbc.banking.utility;

import java.util.Random;

import com.hsbc.banking.models.SimulationThread;
import com.hsbc.banking.models.Vehicle;

public class SimulationApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vehicle vehicle =new Vehicle();
		
		SimulationThread[] simulations=new SimulationThread[5];
		
		for(int i=0;i<simulations.length;i++)
		{			
			simulations[i]=new SimulationThread(vehicle,"Thread-"
			+i,"TN-32-Ak"+new Random().nextInt(10000));
			
		}
		
		
		
	}

}
