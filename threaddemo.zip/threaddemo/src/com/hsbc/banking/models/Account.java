package com.hsbc.banking.models;

//without Synchronization
public class Account {

	private long balance;
	public Account(int amount)
	{
		this.balance=amount;
	}
	
	public void withdraw(int amount) throws InterruptedException
	{
		System.out.println("Before withdraw"+this.balance);
		if(amount<balance)
		{
			Thread.sleep(1000);
			balance-=amount;
			System.out.println("Requested with draw Amount="+amount+"After withdrawal Balance="+balance);
		}
		else
		{
			System.out.println("Requested with draw Amount="+amount+"Balance is lower than amount="+this.balance+", you cannot withdraw");
		}
	}
	
}
