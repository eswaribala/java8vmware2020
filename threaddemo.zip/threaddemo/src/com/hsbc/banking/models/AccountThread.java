package com.hsbc.banking.models;

public class AccountThread implements Runnable{

	private Account accountRef;
	private int withdrawAmount;
	
	//account ref, name of the thread amount
	public AccountThread(Account account, String name, int amount)
	{
		this.accountRef=account;
		this.withdrawAmount=amount;
		new Thread(this,name).start();
		
		
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			
			synchronized(accountRef)
			{
			accountRef.withdraw(withdrawAmount);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
