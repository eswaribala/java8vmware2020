package com.hsbc.banking.models;

import java.util.List;

public class MCQ extends Thread{
	
	private List<Question> questionList;	

	public MCQ(List<Question> questionList) {
		super();
		this.questionList = questionList;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		
		for(Question ques : questionList)
		{
			System.out.println(ques.getQuestionNo()+"\t"+ques.getDescription());
			for(Answer ans : ques.getAnswerList())
			{
				System.out.println("\t"+ans.getAnswerNo()+"\t"+ans.getAnswerDescription());
			}
			System.out.println("*************************************************");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	

}
