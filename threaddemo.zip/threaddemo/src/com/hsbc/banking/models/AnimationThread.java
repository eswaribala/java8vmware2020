package com.hsbc.banking.models;

public class AnimationThread extends Thread{
	private String userName;
	
	public AnimationThread(String name,String userName) {
		super(name);
		// TODO Auto-generated constructor stub
		this.userName=userName;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		System.out.println(Thread.currentThread().getName());
		for(char ch : userName.toCharArray())
		{
			System.out.print(ch+"\t");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
	

}
