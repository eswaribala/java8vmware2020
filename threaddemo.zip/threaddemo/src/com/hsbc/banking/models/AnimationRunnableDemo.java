package com.hsbc.banking.models;

public class AnimationRunnableDemo implements Runnable{

    private String userName;
	private String threadName;
	public AnimationRunnableDemo(String name,String userName) {
		
		// TODO Auto-generated constructor 
	    this.threadName=name;
		this.userName=userName;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Thread.currentThread().setName(this.threadName);
		System.out.println(Thread.currentThread().getName());
		for(char ch : userName.toCharArray())
		{
			System.out.print(ch+"\t");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
