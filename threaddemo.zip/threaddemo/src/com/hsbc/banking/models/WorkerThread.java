package com.hsbc.banking.models;

public class WorkerThread implements Runnable{

	private String threadName;
		
	public WorkerThread(String name) {
		super();
		// TODO Auto-generated constructor stub
		this.threadName=name;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		Thread.currentThread().setName(threadName);
		System.out.println(Thread.currentThread().getName());
	}

}
