package com.hsbc.banking.models;

import java.time.LocalDateTime;
import java.util.Random;

//inter thread communication
public class Tweet implements Runnable{

	private Message message;	
	
	public synchronized void writeTweet() throws InterruptedException
	{
		while(true)
		{
		if(this.message==null)
		{
			System.out.println("Production Thread started message creation:"+Thread.currentThread().getName());
			message=new Message();
			message.setMessageId(new Random().nextInt(10000));
			message.setDescription("Blah Blah Blah...");
			message.setDateTime(LocalDateTime.now());
			Thread.sleep(1000);
			notifyAll();
		}
		else
		{
			System.out.println("Production Thread waiting...:"+Thread.currentThread().getName());
			wait();
		}
		}
		
		
	}
	
	public synchronized void readTweet() throws InterruptedException
	{
		
		while(true)
		{
		if(this.message!=null)
		{
			System.out.println("Consumer Thread started reading message:"+Thread.currentThread().getName());
			
			System.out.println(message.getDescription()+","+message.getDateTime().toString());
			Thread.sleep(1000);
			message=null;
			notify();
		}
		else
		{
			System.out.println("Consumer Thread waiting...:"+Thread.currentThread().getName());
			wait();
		}
		}
		
	}
	
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println(Thread.currentThread().getName());
		
		try
		{
		if(Thread.currentThread().getName().equals("Producer"))
			writeTweet();
		else
			readTweet();
		}
		catch(InterruptedException exception)
		{
			
		}
		
	}

}
