package com.virtusa.shopping.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.models.Product;

public interface ProductDao {

	int addProduct(Product product) throws SQLException;
	List<Object[]> getProducts() throws SQLException;
	Product getProductById(int productId);
	int countProducts(String categoryName) throws SQLException;
	
}
