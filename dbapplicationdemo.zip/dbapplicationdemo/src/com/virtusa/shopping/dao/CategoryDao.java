package com.virtusa.shopping.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.models.Category;

public interface CategoryDao {

	void addCategory(Category category);
	int[] addAllCategory(List<Category> categories) throws SQLException;
	void updateCategory(Category category);
	void deleteCategory(int categoryId);
	List<Category> getCategories() throws SQLException;
	Category getCategoryById(int categoryId) throws SQLException;
	
}
