package com.virtusa.shopping.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLType;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.shopping.helpers.MySQLHelper;
import com.virtusa.shopping.models.Product;

public class ProductImpl implements ProductDao{

	private Connection conn;
	private CallableStatement callable;
	private ResultSet resultSet;
	private ResultSetMetaData metadata;
	@Override
	public int addProduct(Product product) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
		conn.setAutoCommit(false);
	    int count=0;
		try {
			callable=conn.prepareCall("{call addproduct(?,?,?,?,?)}");
			callable.setInt(1, product.getProductId());
			callable.setString(2, product.getProductName());		
			callable.setDate(3, product.getDop());
			callable.setInt(4,product.getCost());
			callable.setInt(5,product.getCategory().getCategoryId());
			count=callable.executeUpdate();
			conn.commit();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			conn.rollback();
		}
		
		finally
		{
			conn.close();
		}
		
		return count;
		
		
	}

	@Override
	public List<Object[]> getProducts() throws SQLException {
		// TODO Auto-generated method stub	
		conn=MySQLHelper.getConnection();
		List<Object[]> objects=new ArrayList<Object[]>();	
		try {
			callable=conn.prepareCall("{call getAllProducts()}");		
			resultSet=callable.executeQuery();
			metadata=resultSet.getMetaData();
			while(resultSet.next())
			{
				Object[] object=new Object[metadata.getColumnCount()];
				for(int i=0;i<metadata.getColumnCount();i++)
				{
					object[i]=resultSet.getObject(i+1);
				}
				
				objects.add(object);
		
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			conn.close();
		}		
		
		return objects;
	}

	@Override
	public Product getProductById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countProducts(String categoryName) throws SQLException {
		// TODO Auto-generated method stub		
		conn=MySQLHelper.getConnection();
		int count=0;
		
		try {
			callable=conn.prepareCall("{call countProductsByCategory(?,?)}");		
			callable.setString(1, categoryName);
			callable.registerOutParameter(2,java.sql.Types.INTEGER);
			callable.execute();
			count=callable.getInt(2);		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			conn.close();
		}	
		
		
		
		return count;
	}

}
