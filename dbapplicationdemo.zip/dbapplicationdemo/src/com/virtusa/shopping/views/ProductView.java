package com.virtusa.shopping.views;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.shopping.dao.CategoryDao;
import com.virtusa.shopping.dao.CategoryImpl;
import com.virtusa.shopping.dao.ProductDao;
import com.virtusa.shopping.dao.ProductImpl;
import com.virtusa.shopping.models.Product;

public class ProductView {

	private static Scanner scanner =new Scanner(System.in);
	private static CategoryDao catDao=new CategoryImpl();
	private static ProductDao dao=new ProductImpl();
	private static Product product;
	
	private static Logger logger=Logger.getLogger(ProductView.class);
	
	static
	{
		PropertyConfigurator.configure("log4j.properties");
	}
	
	
	
	public static void addProduct()
	{
		product=new Product();
		System.out.println("Enter Product Id");
		product.setProductId(scanner.nextInt());
		scanner.nextLine();
		System.out.println("Enter Product Name");
		product.setProductName(scanner.nextLine());
		System.out.println("Enter Product DOP(dd-mm-yyyy)");
		SimpleDateFormat fmt =new SimpleDateFormat("dd-MM-yyyy");
		String date=scanner.nextLine();
		Date dop=null;
		java.util.Date result=null;
		try {
			result=fmt.parse(date);
			dop=new Date(result.getYear(),result.getMonth(),result.getDay());
			
		product.setDop(dop);
		System.out.println("Enter Product Cost");
		product.setCost(scanner.nextInt());
		scanner.nextLine();		
		System.out.println("Enter Category Id");
		product.setCategory(catDao.getCategoryById(scanner.nextInt()));
		int count= dao.addProduct(product);
		if(count>0)
			System.out.println("Record Added!!!!");
		
		} 
		 catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Parsing Exception"+e.getMessage());
		}	
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL Exception"+e.getErrorCode());
		}
				
		
	}
	
	public static void getAllProducts()
	{
	   try {
		for(Object[] objects : dao.getProducts())
		   {
			   for(Object obj : objects)
				   System.out.print(obj+"\t");
			   System.out.println("\n");
		   }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	
	public static void getCount()
	{
		
		logger.info("Product Count Starts by Category Name");
		System.out.println("Enter Category Name");
		try {
			//System.out.println("Count="+dao.countProducts(scanner.nextLine()));
			logger.info("Count="+dao.countProducts(scanner.nextLine()));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			logger.error("SQL Exception"+e.getMessage());
			
		}
	}
	
	
	
	
	
	
}
