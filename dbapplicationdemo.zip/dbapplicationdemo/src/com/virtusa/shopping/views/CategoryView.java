package com.virtusa.shopping.views;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.virtusa.shopping.dao.CategoryDao;
import com.virtusa.shopping.dao.CategoryImpl;
import com.virtusa.shopping.models.Category;

public class CategoryView {
	
	private static Scanner scanner =new Scanner(System.in);
	private static CategoryDao dao=new CategoryImpl();
	private static List<Category> categoryList=new ArrayList<Category>();

	
	
	//get all categories
	public static void getCategories()
	{
		
				
				try {
					for(Category category: dao.getCategories())
					{
						System.out.println(category.getCategoryId()+"\t"+category.getCategoryName());
						
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
	
	//get Category By Id
	public static void getCategoryById()
	{
		
		System.out.println("Enter Category Id");
		Category category;
		try {
			category = dao.getCategoryById(scanner.nextInt());
			System.out.println(category.getCategoryId()+"\t"+category.getCategoryName());	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	//category insert all
	public static void addAllCategories()
	{
		//create categories
	    Category category;
		for(int i=0;i<100;i++)
		{
			category=new Category();
			category.setCategoryId(new Random().nextInt(1000000));
			category.setCategoryName("category-"+i);
			categoryList.add(category);			
		}
		//bulk insert
		try {
			int[] records = dao.addAllCategory(categoryList);
			System.out.println(records);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	
	
	

}
