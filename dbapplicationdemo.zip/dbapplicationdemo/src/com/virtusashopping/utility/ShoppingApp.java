package com.virtusashopping.utility;

import com.virtusa.shopping.views.CategoryView;
import com.virtusa.shopping.views.ProductView;

public class ShoppingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       ProductView.getCount();
	    
	}

}
