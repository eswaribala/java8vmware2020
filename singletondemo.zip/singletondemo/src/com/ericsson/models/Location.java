package com.ericsson.models;

public enum Location 
{ 
	  DEFAULT, USA, INDIA 
	} 
	  