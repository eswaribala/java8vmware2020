package com.ericsson.models;

public interface ImageReader {
    DecodedImage getDecodeImage();
}
